const GAME_ID_TO_URL = {
  "16274": "https://drive.google.com/drive/folders/1H9A9FG1RiH_cb5_ghGsGv9DgmkQxmo6K",
  "5133": "https://drive.google.com/drive/folders/1HwuEYFHtHWAKZb2tZq9qFOMdlRsJyjCH",
  "31905": "https://drive.google.com/drive/folders/1WYoQqZV_tl9toE7z1O7kceO5SUbYq9sb",
  "18684": "https://drive.google.com/drive/folders/1FQK5hci9GPpeVQTmtd40eRv516n3xYLn",
  "19030": "https://drive.google.com/drive/folders/1ZpbrW9PomZTYy9K2iI5oshSTEPM_UlCz",  
  "24704": "https://drive.google.com/drive/folders/1g94mvV3DpeYMVot48JaD2rIG6KqJNBWl",
  "2466": "https://drive.google.com/drive/folders/19muzjDw1oNUD91cDjs630jdoSgD3a0Qd",
  "34705": "https://drive.google.com/drive/folders/1k3gF294z5aMO_I_CuCoiKPJM0QZ-9kxm",
  "11268": "https://drive.google.com/drive/folders/1wuVrP657OSZklYpEvHAfi8XuBA7-h-wp",
  "9459": "https://drive.google.com/drive/folders/1RTLb_8tfLKVfX9v9lpz5v4rwNMtPuk45",
  "2370": "https://drive.google.com/drive/folders/1BX7ZDn6ycYto8JPdniiURd0WvH3fh1Lj",
  "3358": "https://drive.google.com/drive/folders/1C2b95ymQQXQYhaahjiaGA63Wee_DT2xd",
  "14228": "https://drive.google.com/drive/folders/1cJRasbdd41KahSsAFak7uUoS6B-8E7dy",
  "29328": "https://drive.google.com/drive/folders/1sS6wQO7FjKlTErRVUbN6lH1T05Kf79Kp",
  "7140": "https://drive.google.com/drive/folders/1FzmqVwqnae98ahk_tZx_2KUoNX0iXm3h",
  "34704": "https://drive.google.com/drive/folders/1D_qzx8PuNFWMTRI8gMIOpy_cmwnpccTg",
  "3859": "https://drive.google.com/drive/folders/1820S-Z3JQEV8srwjDFkYieMvXucRnuLa",
  "25503": "https://drive.google.com/drive/folders/1Q9rk3EOKWlSCwph3flzb9EZZjO02QgoQ",
  "11245": "https://drive.google.com/drive/folders/1wREXtAbf_0RPXjciqxv1m0AxDMwLEy9_",
  "12748": "https://drive.google.com/drive/folders/1Kdz_pAPlZxya0sqAAsB6xTj-_VOmmWPt",
  "3176": "https://drive.google.com/drive/folders/1IOhMBTgc4F6aqLAnHIPqU-P3kqjt7odW",
  "30888": "https://drive.google.com/drive/folders/19Myf2G4RJJzRgkVO3iLrMa2Wb9-aB7Kr",
  "10077": "https://drive.google.com/drive/folders/19YXekG_iHHXPo6xl5SlxobQDEPzRcbym",
  "9015": "https://drive.google.com/drive/folders/1-1V1THsSwXsLJfGpl-UzpGW0fkqkHZVo",
  "14450": "https://drive.google.com/drive/folders/1uzahqdCXaAQwrJkaxSkqa6xdtL5GshJV",
  "6870": "https://drive.google.com/drive/folders/1Fa5XViDxgiKTYELtHD-UdXgHxvHy60ql",
  "41274": "https://drive.google.com/drive/folders/11Xd5FJIStvosR3p7qpJXXbioj9jRyyTH",
  "16172": "https://drive.google.com/drive/folders/1ljUPvE9UCdYh4GeKBiGdVeLooKMro0OB",
  "11265": "https://drive.google.com/drive/folders/1IlDYKD9mqGg_qAYnZVfXQo4U3878x-9R",
  "2606": "https://drive.google.com/drive/folders/1f_OsiRfkvSivkZSPnflS3oehOjNDoWKY",
  "2356": "https://drive.google.com/drive/folders/1SzLluzPY7nwcrC3sVarAsAniZ5ze60BE",
  "20466": "https://drive.google.com/drive/folders/114_-fVojjk5pe0I7nvqMBm90kfaguvTo",
  "186": "https://drive.google.com/drive/folders/15iViSVSVEcIR4iB3rwm1zFOc6ylMWomY",
  "33782": "https://drive.google.com/drive/folders/1-XjDP7QL3fQJdBWtcyjNG_54XJaKoMNq",
  "41273": "https://drive.google.com/drive/folders/1VsVDlr0aCx30c8FhIBGY1h7MaedN-BHm",
  "17926": "https://drive.google.com/drive/folders/1U5vD9tFFlHF35o4UOPMKoupsyhKMUaIy",
  "17454": "https://drive.google.com/drive/folders/1sxUGJE4aU_e04D0iYoV0sDL3_ArxZ7xG",
  "19022": "https://drive.google.com/drive/folders/1bwO_R_FNHZ7vZBYdeIq0cQH1Ph10vGky",
  "34766": "https://drive.google.com/drive/folders/1zc7ms90RroIBVrKheLbhy678yAFAg3wR",
  "29747": "https://drive.google.com/drive/folders/1YZRY3JNiVWr1nO6atwEVFeerSsBwXkQo",
  "5761": "https://drive.google.com/drive/folders/1HhpYgCcxsgDueFKp-U8HdYnS240SIU3D",
  "5762": "https://drive.google.com/drive/folders/1zOIDQ07xM2C9pO4leF3eJFJ-YXCTIWA-",
  "11419": "https://drive.google.com/drive/folders/1iiq9YsniL_qtbgo4prFDelqMEib5znJi",
  "18733": "https://drive.google.com/drive/folders/1GmThscseYmavb3nzH1ss2Itkd9Wy8k44",
  "97": "https://drive.google.com/drive/folders/1A1Z73eULODqImPuHGPAkpHLPr7_Q4off",
  "20478": "https://drive.google.com/drive/folders/1qwc5D4e6kVr37RJ0nMrD6BTFkfjEQ_op",
  "3866": "https://drive.google.com/drive/folders/1SeZLfes9dDbQslUqlWCnmqqZiqTSIiyC",
  "6871": "https://drive.google.com/drive/folders/1F4nRcsB3zK6-V-gRooy6IG-AKnb06xI1",
  "1303": "https://drive.google.com/drive/folders/1GWTiIfe6kHsAEO9D3ZGXs924bdA0ny1y",
};

const OLD_TEXT = "Supported Game Hashes";
const NEW_TEXT = "Download Game";

function getCurrentGameId() {
  const m = window.location.pathname.match(/^\/game\/(\d+)/);
  return m ? m[1] : null;
}

function hideUntilReplaced(link) {
  if (link.dataset.raReplaced === "1") return;
  if (link.dataset.raHidden === "1") return;
  link.dataset.raHidden = "1";
  link.style.visibility = "hidden";
}

function revealIfNotReplaced(link) {
  if (link.dataset.raReplaced === "1") return;
  if (link.dataset.raHidden !== "1") return;
  link.style.visibility = "";
  link.dataset.raHidden = "0";
}

function applyReplacements() {
  const gameId = getCurrentGameId();
  const newUrl = gameId ? GAME_ID_TO_URL[gameId] : null;

  const links = document.querySelectorAll('a[href*="/hashes"]');

  links.forEach(link => {
    if (link.dataset.raReplaced === "1") return;

    if (!gameId || !newUrl) {
      revealIfNotReplaced(link);
      return;
    }

    const href = link.getAttribute('href') || '';
    if (!href.includes(`/game/${gameId}/hashes`)) {
      revealIfNotReplaced(link);
      return;
    }

    if (!link.textContent.includes(OLD_TEXT)) {
      revealIfNotReplaced(link);
      return;
    }

    hideUntilReplaced(link);

    link.setAttribute('href', newUrl);

    const iconSpan = link.querySelector('span > svg')?.parentElement;

    link.textContent = '';

    const wrapper = document.createElement('span');
    wrapper.className = 'flex items-center gap-2';

    if (iconSpan) wrapper.appendChild(iconSpan);

    const textSpan = document.createElement('span');
    textSpan.className = 'flex items-center gap-1';
    textSpan.textContent = NEW_TEXT;
    wrapper.appendChild(textSpan);

    link.appendChild(wrapper);

    link.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      window.open(newUrl, '_blank', 'noopener,noreferrer');
    }, true);

    link.dataset.raReplaced = "1";
    link.style.visibility = "";
    link.dataset.raHidden = "0";
  });
}

const observer = new MutationObserver(applyReplacements);
observer.observe(document.documentElement, { childList: true, subtree: true });

setInterval(applyReplacements, 300);

applyReplacements();